# Giới thiệu

Chương trình dùng để tạo một socketServer
Hãy tham khảo bài viết để biết thêm chi tiết tại http://arduino.vn/node/1511
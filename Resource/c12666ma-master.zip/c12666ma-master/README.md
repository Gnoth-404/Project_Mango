# c12666ma
For More Information pleave visit this project site
https://groupgets.com/manufacturers/hamamatsu-photonics/products/c12666ma-micro-spectrometer

Quick How-TO

Checkout the code I have posed here:
https://github.com/groupgets/c12666ma

Also get yourself an arduino uno if you don't have one already. 
http://www.mouser.com/ProductDetail/Arduino/A000066/?qs=BC3YYPaifMrIue9b%252bHtKQg%3D%3D&kpid=630043477&gclid=CPb12-2phMYCFQeKaQodqpYA8w

next download the arduino environment. 
http://www.arduino.cc/en/Main/Software

And for visulization you can use processing 
https://processing.org/download/?processing


put the spectrometer into the breakout board. 
alight the breakout board so the 5V and 3.3V and GND pins line up. EOS will be unconnected in the center. 
Download the code onto the arduino. 
you will have to modify the processing script to open the correct serial port. 

Please if there are any improvements of fixes please submit a push request and it should be accepted. Thanks! 
